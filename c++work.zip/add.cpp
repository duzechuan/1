#include <iostream>
#include <cmath>
using namespace std;
class Vector {
private:
    double x;
    double y;

public:
    // 构造函数
    Vector(double xVal, double yVal) : x(xVal), y(yVal) {}

    // 向量相加方法
    Vector add(const Vector& other) const {
        return Vector(x + other.x, y + other.y);
    }

    // 打印向量分量方法
    void print() const {
        std::cout << "向量的分量为: (" << x << ", " << y << ")" << std::endl;
    }

    // 求取并打印向量模长的方法
    void dir() const {
        double magnitude = std::sqrt(x * x + y * y);
        std::cout << "向量的模长为: " << magnitude << std::endl;
    }
};
int main() {
    Vector v1(3.0, 4.0);
    Vector v2(1.0, 2.0);

    // 打印v1的分量和模长
    v1.print();
    v1.dir();

    // 向量相加并打印结果向量的分量和模长
    Vector sum = v1.add(v2);
    sum.print();
    sum.dir();

    return 0;
}